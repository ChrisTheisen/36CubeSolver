This program solves the 36Cube 'logic' puzzle.


Options:
GO -> Clears any previously found solutions and starts finding solutions from the beginning.  
	Note: (takes about 3 minutes to check all posibilities when not 'Draw Trials' or about 3 days to draw all possibilities.)
Stop -> Stops searching and populates solutions tab.
Draw Trials -> When checked draws out the current board state (makes finding solutions go significantly slower).

Trials Tab:
When 'Draw Trials' is selected the current attempt is drawn here.

Solutions tab:
All discovered solutions will be viewable here.
Use the dropdown selector to change between discovered solutions.
